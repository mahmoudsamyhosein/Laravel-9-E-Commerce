-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 03 أبريل 2022 الساعة 05:19
-- إصدار الخادم: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mshmk_shop`
--

-- --------------------------------------------------------

--
-- بنية الجدول `attribute_values`
--

CREATE TABLE `attribute_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_attribute_id` bigint(20) UNSIGNED DEFAULT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'ملابس', 'ملابس', NULL, NULL),
(2, 'مستحضرات تجميل', 'مستحضرات تجميل', NULL, NULL),
(3, 'عطور', 'عطور', '2022-04-02 06:00:51', '2022-04-02 06:00:51'),
(4, 'أحذية', 'أحذية', NULL, NULL),
(5, 'هواتف', 'هواتف', NULL, NULL),
(6, 'مستحضرات تجميل', 'مستحضرات تجميل', NULL, NULL);

-- --------------------------------------------------------

--
-- بنية الجدول `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `phone`, `comment`, `created_at`, `updated_at`) VALUES
(2, 'محمود سامي حسين متولي', 'test@gmail.com', '10102122', 'test message for this form', '2022-04-02 04:59:28', '2022-04-02 04:59:28');

-- --------------------------------------------------------

--
-- بنية الجدول `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(8,2) NOT NULL,
  `cart_value` decimal(8,2) NOT NULL,
  `expiry_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `coupons`
--

INSERT INTO `coupons` (`id`, `code`, `type`, `value`, `cart_value`, `expiry_date`, `created_at`, `updated_at`) VALUES
(1, 'offnow', 'fixed', '120.00', '1200.00', '2022-04-30', '2022-04-02 06:42:36', '2022-04-02 06:42:36');

-- --------------------------------------------------------

--
-- بنية الجدول `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `homesliders`
--

CREATE TABLE `homesliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `homesliders`
--

INSERT INTO `homesliders` (`id`, `title`, `subtitle`, `price`, `link`, `image`, `status`, `created_at`, `updated_at`) VALUES
(114, 'أزياء', 'أحدث صيحات الموضة', '12', 'http://mshmk_shop.test/product/et-facilis-atque-fuga', '1648770036.jpg', 1, '2022-03-30 09:48:39', '2022-03-31 21:40:36'),
(115, 'أثاث', 'بأسعار خيالية', '1200', 'http://mshmk_shop.test/product/quisquam-enim-dolorum-doloremque', '1648766625.jpg', 1, '2022-03-31 20:19:31', '2022-03-31 20:43:45'),
(116, 'ملابس', 'تسوق الأن ملابس للأطفال بأسعار خيالية', '124', 'http://mshmk_shop.test/product/culpa-placeat-repudiandae-molestiae', '1648766646.jpg', 1, '2022-03-31 20:20:24', '2022-03-31 20:44:23');

-- --------------------------------------------------------

--
-- بنية الجدول `home_categories`
--

CREATE TABLE `home_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sel_categories` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_of_products` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `home_categories`
--

INSERT INTO `home_categories` (`id`, `sel_categories`, `no_of_products`, `created_at`, `updated_at`) VALUES
(1, '1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17', 121, NULL, '2022-03-31 22:10:34');

-- --------------------------------------------------------

--
-- بنية الجدول `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '1989_03_11_085942_create_settings_table', 1);

-- --------------------------------------------------------

--
-- بنية الجدول `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `subtotal` decimal(8,2) NOT NULL,
  `discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(8,2) NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `line1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('ordered','delivered','canceled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ordered',
  `is_shipping_different` tinyint(1) NOT NULL DEFAULT '0',
  `delivered_date` date DEFAULT NULL,
  `canceled_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `subtotal`, `discount`, `tax`, `total`, `firstname`, `lastname`, `mobile`, `email`, `line1`, `line2`, `city`, `province`, `country`, `zipcode`, `status`, `is_shipping_different`, `delivered_date`, `canceled_date`, `created_at`, `updated_at`) VALUES
(1, 35, '496.00', '0.00', '104.16', '600.16', 'test', 'test', '01010101010', 'test@gmail.com', 'testorders', 'testorders', 'testorders', 'testorders', 'testorders', 'testorders', 'ordered', 0, NULL, NULL, '2022-04-02 02:12:33', '2022-04-02 02:12:33'),
(2, 35, '11.00', '0.00', '2.00', '13.00', 'mahmoud', 'hosein', '+201006399580', 'souqfreeshiping@gmail.com', 'z\\xxxxxxxxxxxxxxxxxxxxx', 'z\\xxxxxxxxxxxxxxxxxxxxx', 'almostaqbal city', 'Ismailia', 'Egypt', '41639', 'ordered', 0, NULL, NULL, '2022-04-02 06:26:19', '2022-04-02 06:26:19');

-- --------------------------------------------------------

--
-- بنية الجدول `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `price` decimal(8,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rstatus` tinyint(1) NOT NULL DEFAULT '0',
  `options` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `order_items`
--

INSERT INTO `order_items` (`id`, `product_id`, `order_id`, `price`, `quantity`, `rstatus`, `options`, `created_at`, `updated_at`) VALUES
(14, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 04:34:28', '2022-03-29 04:34:28'),
(15, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 04:37:54', '2022-03-29 04:37:54'),
(16, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 04:39:26', '2022-03-29 04:39:26'),
(17, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 04:42:58', '2022-03-29 04:42:58'),
(18, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 04:44:41', '2022-03-29 04:44:41'),
(19, 48, NULL, '415.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 04:45:54', '2022-03-29 04:45:54'),
(20, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 04:46:49', '2022-03-29 04:46:49'),
(21, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 04:50:00', '2022-03-29 04:50:00'),
(22, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 03:59:32', '2022-03-30 03:59:32'),
(23, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 04:02:13', '2022-03-30 04:02:13'),
(24, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 05:38:44', '2022-03-30 05:38:44'),
(25, NULL, NULL, '408.00', 1, 1, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 07:35:29', '2022-03-30 08:28:48'),
(26, NULL, NULL, '496.00', 1, 1, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 07:35:29', '2022-03-30 09:00:08'),
(27, NULL, NULL, '408.00', 1, 1, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 07:56:59', '2022-03-30 09:07:58'),
(28, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 07:56:59', '2022-03-30 07:56:59'),
(29, NULL, NULL, '408.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 09:04:42', '2022-03-30 09:04:42'),
(30, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 09:04:42', '2022-03-30 09:04:42'),
(31, NULL, NULL, '496.00', 2, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 09:14:48', '2022-03-30 09:14:48'),
(32, NULL, NULL, '496.00', 1, 1, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-31 09:55:42', '2022-03-31 10:07:29'),
(33, NULL, NULL, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-31 10:29:12', '2022-03-31 10:29:12'),
(34, 48, NULL, '415.00', 7, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-31 13:47:39', '2022-03-31 13:47:39'),
(35, NULL, 1, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-04-02 02:12:34', '2022-04-02 02:12:34'),
(36, NULL, 2, '496.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-04-02 06:26:19', '2022-04-02 06:26:19'),
(37, 92, 2, '11000.00', 1, 0, 'O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-04-02 06:26:19', '2022-04-02 06:26:19');

-- --------------------------------------------------------

--
-- بنية الجدول `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('souqfreeshiping@gmail.com', '$2y$10$HCkDumpsdwatg9kM9WDxWOGmD7gisKemaBluUT5lT4a9aBUrVZ9Ju', '2022-03-10 16:24:21');

-- --------------------------------------------------------

--
-- بنية الجدول `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `regular_price` decimal(8,2) NOT NULL,
  `sale_price` decimal(8,2) DEFAULT NULL,
  `SKU` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_status` enum('instock','outofstock') COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `quantity` bigint(20) UNSIGNED NOT NULL DEFAULT '10',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subcategory_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `products`
--

INSERT INTO `products` (`id`, `name`, `slug`, `short_description`, `description`, `regular_price`, `sale_price`, `SKU`, `stock_status`, `featured`, `quantity`, `image`, `images`, `category_id`, `subcategory_id`, `created_at`, `updated_at`) VALUES
(48, 'new', 'new', 'Hic aut maxime inventore tempora error id et. Iusto quia praesentium est amet. Iure qui sunt harum quidem recusandae.', 'Consequuntur similique praesentium aut iure beatae ipsam. Est saepe reprehenderit id veritatis libero. Veniam laboriosam laboriosam tempore voluptas. Quo ut beatae voluptas delectus asperiores quasi quia. Nemo explicabo est porro. Ut cum labore nihil qui laborum tenetur. Praesentium vero ipsam exercitationem sint. Voluptas alias et molestiae ea. Maiores hic est inventore provident voluptates explicabo.', '415.00', '368.00', 'DIGI146', 'instock', 0, 125, 'digital_10.jpg', ',16486387240.jpg', 6, NULL, '2022-03-29 04:11:53', '2022-03-30 09:12:04'),
(51, 'test', 'test', '<p>وصف قصير للمنتج</p>', '<p>وصف قصير للمنتج</p>', '235.00', '496.00', 'DIGI269', 'instock', 0, 124, 'digital_8.jpg', ',16486397240.jpg,16486397251.jpg,16486397252.jpg,16486397253.jpg,16486397254.jpg,16486397255.jpg', 2, NULL, '2022-03-29 04:11:54', '2022-03-30 09:28:45'),
(52, 'quisquam enim dolorum doloremque', 'quisquam-enim-dolorum-doloremque', 'Rerum molestias ipsa voluptatem enim ut. Consequuntur possimus impedit consequuntur est ut dolor. Suscipit corporis laboriosam ut ut quibusdam.', 'Et ut officiis harum ab maxime inventore magni. Nobis recusandae minus quibusdam. Repellat consequuntur occaecati similique unde facilis et sed. Fuga quae ipsam ut aperiam voluptates inventore. Quasi dolores qui nemo non aut maxime iste ut. Totam et ut itaque et sequi eaque hic. Debitis ut dolores molestias aut nulla. Ut sunt magni doloribus qui minus non voluptatum.', '392.00', '124.00', 'DIGI234', 'instock', 0, 109, 'digital_20.jpg', NULL, 6, NULL, '2022-03-29 04:11:54', '2022-03-29 04:11:54'),
(53, 'et aperiam saepe rerum', 'et-aperiam-saepe-rerum', 'Ratione doloremque atque quaerat alias. Soluta iusto odio dolores ut dolor. Et est beatae esse eos hic officia fugit. Impedit ab in aut consequatur.', 'Quo accusamus voluptatem aut aut sit. Et quia cum et aspernatur quisquam repellat. Nisi et illo consequatur et id quibusdam qui quidem. Deserunt et aspernatur voluptates eos. Unde sed necessitatibus harum id illum. Qui quis aliquid sapiente cumque ex aut ipsum. Quod cupiditate excepturi ex pariatur. Praesentium quo expedita blanditiis. Non optio ut aperiam fuga aspernatur ut doloribus.', '284.00', '232.00', 'DIGI318', 'instock', 0, 168, 'digital_2.jpg', NULL, 6, NULL, '2022-03-29 04:11:54', '2022-03-29 04:11:54'),
(54, 'et dolores omnis non', 'et-dolores-omnis-non', 'Itaque et ad id hic quos laboriosam voluptatum et. Quia rerum sed a sequi eos deleniti. Quisquam est aut necessitatibus.', 'Eaque earum similique qui dolore quasi pariatur est omnis. Error enim vel natus eos doloribus nesciunt sunt. Veritatis inventore qui earum voluptatibus repudiandae alias. Velit est aut iste at. In quia ipsum corrupti ut impedit. Dignissimos qui qui sed iure et non non. Et et atque possimus pariatur ullam assumenda. Voluptatum consequatur et modi similique. Veniam sit consequatur sed qui. Et quibusdam sit exercitationem. Voluptatum nihil facilis consequuntur eos ipsum.', '212.00', '475.00', 'DIGI262', 'instock', 0, 180, 'digital_13.jpg', NULL, 1, NULL, '2022-03-29 04:11:54', '2022-03-29 04:11:54'),
(55, 'officia reiciendis maxime qui', 'officia-reiciendis-maxime-qui', 'Tempore doloremque quo culpa quis ducimus veritatis. Id reiciendis modi voluptate autem laudantium non esse. Voluptatum omnis dolor qui sed sapiente in. Error quis eaque vero dolorum hic officia.', 'Eum dolor recusandae iusto eius aut repellat qui. Blanditiis at quos tempore qui illo est. Dicta soluta veritatis harum. Enim fugiat optio qui. Asperiores possimus sed sint sunt. Iure ut ipsam perferendis saepe distinctio alias. Neque deleniti facilis sed animi culpa voluptas quisquam ratione. Facere sint autem ab facere iusto. Enim hic minus sunt ullam unde rerum.', '118.00', '400.00', 'DIGI197', 'instock', 0, 185, 'digital_1.jpg', NULL, 4, NULL, '2022-03-29 04:11:54', '2022-03-29 04:11:54'),
(56, 'labore id ut sapiente', 'labore-id-ut-sapiente', 'Eum est et quos sint unde et. Est unde ut optio dolor. Sunt minima est earum quis.', 'Dolorem possimus nulla ipsam ipsam cum. Similique iste ex sapiente commodi ipsum quis et. Et voluptatem quia dolorum corrupti ratione. Delectus nobis quis laboriosam officiis. Rem officiis omnis necessitatibus inventore sint. Est est accusamus magnam optio. Cumque quisquam architecto non labore ratione consectetur similique. Ab vitae recusandae sapiente ea voluptas est qui inventore. Animi quidem quia quod quasi. Adipisci quidem rerum et reprehenderit quibusdam eveniet illo.', '488.00', '245.00', 'DIGI493', 'instock', 0, 104, 'digital_11.jpg', NULL, 2, NULL, '2022-03-29 04:11:55', '2022-03-29 04:11:55'),
(57, 'dolor ut ab suscipit', 'dolor-ut-ab-suscipit', 'Ullam quibusdam quo adipisci et aliquid. Rerum beatae sunt fugiat aliquam. Iste iure ea quibusdam nobis repellendus iste. Maiores voluptatem velit quae quas velit facilis enim voluptas.', 'Voluptatem quidem quod dicta. Voluptatum unde est sed sapiente aut minima. Nihil impedit atque qui doloribus porro accusantium fugit. Eum totam ea blanditiis consectetur debitis occaecati ad. Temporibus a dolorem corporis eos beatae cum et. Nesciunt sed nihil aut quae similique omnis. Consequatur autem non facere neque dolorum delectus fugiat ea.', '180.00', '141.00', 'DIGI408', 'instock', 0, 178, 'digital_9.jpg', NULL, 2, NULL, '2022-03-29 04:11:55', '2022-03-29 04:11:55'),
(58, 'ex necessitatibus autem eveniet', 'ex-necessitatibus-autem-eveniet', 'Illo dolor vitae incidunt a similique earum. Et blanditiis eius expedita voluptatem ea laborum. Eum assumenda asperiores suscipit.', 'Necessitatibus est earum delectus dolorem. Rerum omnis ullam ducimus voluptates. Sapiente et est veniam quia nobis eos doloribus error. Laudantium vel omnis rem cupiditate officiis quo sunt reiciendis. Quam tempore dolor repellendus ipsa ab quasi. Tempora rerum aut ea aut blanditiis. Quam veritatis qui ipsa natus incidunt provident eum. Deleniti asperiores aut hic nostrum quaerat veniam illo cumque.', '436.00', '318.00', 'DIGI150', 'instock', 0, 182, 'digital_16.jpg', NULL, 5, NULL, '2022-03-29 04:11:55', '2022-03-29 04:11:55'),
(59, 'et facilis atque fuga', 'et-facilis-atque-fuga', 'Voluptatum et ullam quo quasi. Aliquid mollitia aspernatur tempora iure aut. Repellendus quis voluptatem pariatur aut quae quis libero.', 'Commodi suscipit nisi totam at ipsa pariatur repellat. Enim quam ad blanditiis reprehenderit perspiciatis fugit. Exercitationem voluptatem repellendus explicabo praesentium quia vitae qui distinctio. Eos officiis error atque quo quas architecto. Id recusandae officia veritatis. Velit et consequatur numquam quidem in. Et consequatur asperiores quia quidem. Consequatur autem nemo assumenda ab rerum dolor. Beatae sunt maiores eum.', '404.00', '273.00', 'DIGI454', 'instock', 0, 101, 'digital_14.jpg', NULL, 5, NULL, '2022-03-29 04:11:55', '2022-03-29 04:11:55'),
(60, 'recusandae vitae quibusdam voluptas', 'recusandae-vitae-quibusdam-voluptas', 'Unde doloremque hic provident voluptatem et. Culpa in qui quam praesentium ea sint quibusdam. Harum blanditiis qui asperiores debitis hic.', 'Dolores in eos quam ut soluta. Magni aspernatur est asperiores nostrum non. Excepturi voluptatum tenetur numquam modi quia odit atque. Esse deserunt natus sunt non. Vitae id voluptate fugiat porro. Deleniti sed enim et assumenda neque non rem. Dolor est est maiores inventore maiores. Rem iure temporibus maiores non porro. Ea quod voluptates dolorem. Saepe veritatis consectetur quia amet voluptas.', '311.00', '207.00', 'DIGI257', 'instock', 0, 126, 'digital_17.jpg', NULL, 2, NULL, '2022-03-29 04:11:55', '2022-03-29 04:11:55'),
(61, 'minus commodi unde odit', 'minus-commodi-unde-odit', 'Vero et dolores eum magnam aut pariatur. Qui error aut commodi aut quaerat quos eum tempore. Placeat excepturi sit voluptatibus tempora. Voluptas rerum aut quaerat dolor.', 'Pariatur perspiciatis eum provident veritatis impedit reprehenderit aliquid. Laborum eum saepe veniam. Pariatur repudiandae sit perspiciatis aliquid nulla velit officiis. Non accusantium reiciendis placeat aut quis. Voluptate sed consequuntur quidem deserunt. Sequi commodi labore aut sit iusto enim sequi ad. Voluptatem nemo voluptatem est.', '491.00', '420.00', 'DIGI135', 'instock', 0, 190, 'digital_18.jpg', NULL, 6, NULL, '2022-03-29 04:11:56', '2022-03-29 04:11:56'),
(62, 'molestias error recusandae natus', 'molestias-error-recusandae-natus', 'Dolor nobis amet magnam molestiae quas. At id praesentium aliquam. Perspiciatis recusandae quo quasi voluptatem ut saepe omnis vero.', 'Ad qui laborum possimus quod molestiae quia qui excepturi. Iure quo eius et assumenda. Vitae beatae quod nesciunt autem eveniet aut. Natus sit ut unde qui at. Quia et alias atque blanditiis cupiditate occaecati. Dolores aut et suscipit dolore illum. Itaque eveniet sed explicabo. Autem doloremque at illo dolor atque nesciunt voluptatem. Excepturi deleniti aut eum quibusdam odit natus perferendis asperiores. Deleniti doloribus sed voluptates deleniti et eum commodi.', '102.00', '252.00', 'DIGI221', 'instock', 0, 133, 'digital_21.jpg', NULL, 1, NULL, '2022-03-29 04:11:56', '2022-03-29 04:11:56'),
(63, 'hic soluta ipsa quaerat', 'hic-soluta-ipsa-quaerat', 'Soluta autem voluptas optio voluptatibus quae. Est est libero nihil sed esse. Ipsam at in in. Nostrum id id tenetur quia. Odit quas ex expedita nesciunt ab. Quia quis dolor unde sit earum quo.', 'Aspernatur fugit aut sunt qui. Aut in temporibus asperiores porro vel et mollitia in. Nobis facilis nulla enim ipsa consequatur consequatur a. Hic quia in non rem quam omnis rerum. Cumque ut eveniet debitis. Consequatur ipsam cupiditate odio in qui eaque a. At quidem veritatis minima et dolor corporis quasi. Facere velit cupiditate at voluptas. Error quia saepe odit sequi quam perspiciatis. Ut facilis fuga vel.', '312.00', '105.00', 'DIGI132', 'instock', 0, 104, 'digital_12.jpg', NULL, 2, NULL, '2022-03-29 04:11:56', '2022-03-29 04:11:56'),
(64, 'id totam quia asperiores', 'id-totam-quia-asperiores', 'Illo laudantium optio id error laborum. Sed et qui possimus voluptas amet et fuga. Et dolores ea est ut deleniti quasi sint. Nesciunt perspiciatis dolor quia.', 'Occaecati totam autem natus ut aliquam odit id. Deleniti aut quisquam corrupti quod. Deserunt quasi repellendus recusandae corporis rerum amet. Nostrum architecto dicta pariatur ut impedit voluptatem soluta. Ut ab vitae fugiat dolores qui. Iste quis aut natus fugiat. Et expedita dolores sed repellat. Totam laudantium fugit modi reprehenderit. Ut quae accusamus sunt aperiam. Aut ut enim ratione consequatur necessitatibus in. Voluptatem est tenetur odit commodi quia aut.', '351.00', '385.00', 'DIGI134', 'instock', 0, 170, 'digital_15.jpg', NULL, 4, NULL, '2022-03-29 04:11:56', '2022-03-29 04:11:56'),
(65, 'qui est id minima', 'qui-est-id-minima', 'Ipsum quod placeat omnis. Quia ut quo itaque accusantium et numquam molestias. Doloremque odit ullam assumenda numquam. Ut ad exercitationem sed ullam.', 'Est dicta quam minus minus aliquid repellat. Maxime et enim quo aliquid laboriosam ullam. Quaerat eius officia est dolorem qui corporis ut aliquam. Omnis reprehenderit voluptas voluptatem soluta. Qui cupiditate ut sed ut et. Facere quasi qui ipsum eaque expedita vel impedit voluptatem. Provident iste doloribus nemo voluptatem explicabo dolorum dolore. Atque et et officiis et impedit omnis ipsam facilis.', '185.00', '339.00', 'DIGI404', 'instock', 0, 124, 'digital_5.jpg', NULL, 4, NULL, '2022-03-29 04:11:56', '2022-03-29 04:11:56'),
(66, 'in et molestiae autem', 'in-et-molestiae-autem', 'Et enim hic unde beatae. Qui sunt est ipsam sit accusantium sed. Culpa adipisci similique dolores quam voluptas reiciendis. Quas omnis architecto et debitis suscipit.', 'Deserunt voluptas saepe iusto velit sint reprehenderit rerum odit. Adipisci corporis voluptatem quis cupiditate natus magnam doloribus. Animi nostrum molestiae quas vero vitae similique. Officia illo et necessitatibus dolor. Repellendus omnis accusamus tempore officiis tenetur. Et repudiandae eius nam cupiditate rerum aliquid. Atque laboriosam corrupti ut provident. Error quisquam quaerat sed magnam quos et. Et natus aliquid at perferendis accusantium.', '410.00', '226.00', 'DIGI187', 'instock', 0, 115, 'digital_22.jpg', NULL, 4, NULL, '2022-03-29 04:11:56', '2022-03-29 04:11:56'),
(67, 'est voluptas velit nostrum', 'est-voluptas-velit-nostrum', 'Et consequuntur molestias rerum aut. Excepturi aut qui et minus praesentium. Autem omnis voluptatibus qui blanditiis quia sit quibusdam.', 'Non cum voluptates assumenda. Molestiae eos expedita est est. Enim et alias voluptas aliquam recusandae quaerat. Rerum amet non et error corporis quam quo. Neque odio at quidem enim hic et omnis. Voluptatibus provident quia aut velit vero quis. Aut accusamus unde magni quia tempore in. Pariatur fugiat dignissimos deserunt non voluptatem qui consequatur. Aliquam similique voluptas numquam impedit qui. Ex et et sit ut voluptatem vitae.', '226.00', '188.00', 'DIGI456', 'instock', 0, 106, 'digital_19.jpg', NULL, 1, NULL, '2022-03-29 04:11:56', '2022-03-29 04:11:56'),
(68, 'natus at autem ducimus', 'natus-at-autem-ducimus', 'Quo et tempora magnam magni earum aliquam. Et qui quo quia et est eaque explicabo quas. Nihil omnis qui et consectetur omnis consequatur odio aut.', 'Totam id enim placeat animi quis. Consectetur aliquam debitis culpa nemo sequi officiis iusto enim. Eligendi minus eius sit nemo sequi culpa beatae. Sapiente provident et doloremque ut itaque sit. Corporis quos ipsum sit cupiditate. Qui a et impedit harum cum ducimus dicta. Omnis vitae repellat quae veniam. Esse ut harum laboriosam sint iure dolorem. Quo sint magnam cupiditate voluptatum dolores culpa. Doloremque assumenda est voluptate ullam.', '198.00', '309.00', 'DIGI459', 'instock', 0, 188, 'digital_4.jpg', NULL, 4, NULL, '2022-03-29 04:11:56', '2022-03-29 04:11:56'),
(69, 'et accusantium tempore inventore', 'et-accusantium-tempore-inventore', 'Quia sed rem molestias ut voluptatem numquam. Expedita molestiae voluptatem quo voluptatem architecto quis. Ut voluptatum necessitatibus non id quod ut. Sit est voluptatum natus qui totam.', 'Possimus iure accusantium iste et. Quia odit magnam exercitationem. Non qui omnis eaque quia est temporibus sit. Qui dolore neque quos aut ut porro. Voluptas quia quo magnam et sint dolor facere. Asperiores quibusdam officiis ab voluptatibus. Quis sapiente aliquid a et mollitia culpa accusamus. Porro cupiditate molestiae voluptatibus. Laudantium inventore id saepe rem sunt alias quod. Sunt laborum quod unde ut dolorem fuga ipsam. Assumenda natus culpa omnis possimus officiis.', '174.00', '446.00', 'DIGI225', 'instock', 0, 175, 'digital_6.jpg', NULL, 5, NULL, '2022-03-29 04:11:57', '2022-03-29 04:11:57'),
(70, 'possimus eum in omnis', 'possimus-eum-in-omnis', 'Quis deleniti laborum labore officiis assumenda dolorum quidem doloribus. Sed nemo quia et. Culpa omnis aliquid aliquid quis error dolores quae. Voluptatibus odit doloremque aut.', 'Nemo ex ut laudantium ipsa vitae quam alias. Occaecati dolorum libero itaque deleniti ea. Maiores dolor quas maiores blanditiis alias animi et. Officia non tempore voluptate eligendi voluptate. Necessitatibus officia quo iste modi eum aspernatur. Vero assumenda et est pariatur quas et. Exercitationem officiis et illo est hic quo. Et ipsa et ut laboriosam. Autem perspiciatis laborum nam aut quia sint.', '408.00', '111.00', 'DIGI263', 'instock', 0, 137, 'digital_13.jpg', NULL, 5, NULL, '2022-03-29 04:18:00', '2022-03-29 04:18:00'),
(71, 'est sunt dolores ut', 'est-sunt-dolores-ut', 'Odio optio nam sit qui voluptatem doloribus. Maxime alias odit sunt iste. Similique veniam id rerum officia eaque beatae ratione velit.', 'Nobis ea quia ab reprehenderit enim vel. Vero veritatis architecto saepe et non ut aliquam. Ratione et velit et qui qui. Eos consequatur voluptatem optio et. Voluptatem sit nisi reprehenderit voluptatum. Aut magnam dolor sint vel nostrum harum. Et harum rerum a eum ut nihil. Dolor esse ut voluptas sequi deleniti consequatur. Omnis est possimus molestiae omnis expedita. Fugit ut laboriosam voluptates. Perferendis eius dolorem voluptate in quasi repellendus. Rerum voluptas sunt nisi et nulla.', '214.00', '429.00', 'DIGI413', 'instock', 0, 189, 'digital_5.jpg', NULL, 4, NULL, '2022-03-29 04:18:00', '2022-03-29 04:18:00'),
(72, 'dolorem et accusamus voluptatem', 'dolorem-et-accusamus-voluptatem', 'Perspiciatis dolor dolorum molestias enim. Error et quis in corrupti animi rerum deserunt. Ad in pariatur dolorem nulla. Rerum quibusdam quod et ut ipsam et molestiae omnis.', 'Sunt porro itaque eum suscipit et optio. Eveniet voluptas similique quam ipsam sequi. Id doloremque ut asperiores ab. Asperiores deleniti praesentium nihil nostrum dolores et. Maxime deserunt veniam ut voluptatem nesciunt at autem. Sint blanditiis voluptates aut natus dolores. Quia nobis ad sed debitis expedita omnis accusantium. Non facere illum tempora iure. Dicta voluptatem officiis numquam asperiores. Voluptatem illum velit vitae aut reprehenderit dolores quod.', '226.00', '452.00', 'DIGI372', 'instock', 0, 182, 'digital_11.jpg', NULL, 4, NULL, '2022-03-29 04:18:00', '2022-03-29 04:18:00'),
(73, 'quidem et placeat impedit', 'quidem-et-placeat-impedit', 'Et sit blanditiis non recusandae iusto magni corrupti. Culpa fugiat molestias ut labore et. Nam quod consequatur ipsam animi non. Vel hic iure illum cum ad mollitia ut.', 'Rerum qui neque dolor eum. Magnam quam qui autem aut nobis quo vel. Reprehenderit voluptatem ducimus in facilis quis et. Eos autem ut veniam. Saepe ea doloremque modi. Voluptate et cupiditate unde libero quam eos. Non magni laudantium deserunt illo. Ullam consequuntur soluta libero pariatur. Et quod at quo vero. Corrupti inventore sint harum eos non.', '154.00', '315.00', 'DIGI427', 'instock', 0, 132, 'digital_19.jpg', NULL, 5, NULL, '2022-03-29 04:18:00', '2022-03-29 04:18:00'),
(74, 'illo distinctio ut accusamus', 'illo-distinctio-ut-accusamus', 'Dolore aut est ab temporibus aut ipsam. Tempora quidem est dolor voluptatem dolorem. Iusto eveniet earum qui aspernatur veniam aut. Quo quia occaecati incidunt praesentium.', 'Recusandae perferendis omnis quae ea repellendus voluptatem. Molestiae ut delectus ea eveniet nam et. Voluptatem illum voluptas molestiae non fugit repudiandae. Commodi odit ullam consequuntur quo voluptatem. Quia nihil error error est. Quam culpa optio quia. Ea nobis ipsum quia ex et. Alias qui veniam dolorum aut. Vel recusandae ipsam nam molestias quidem. Dolor eum qui eaque culpa.', '258.00', '108.00', 'DIGI291', 'instock', 0, 138, 'digital_8.jpg', NULL, 5, NULL, '2022-03-29 04:18:00', '2022-03-29 04:18:00'),
(75, 'alias culpa aut veritatis', 'alias-culpa-aut-veritatis', 'Excepturi aut sit pariatur tempora consequuntur. Tempora quam fugit quisquam aliquid suscipit. Autem saepe placeat sed soluta aut. Est consectetur dicta qui totam ex asperiores cum.', 'Sit ipsum magnam et provident iusto. Et atque aut mollitia dolore. Velit dolores ducimus et voluptas architecto ab. Similique similique rerum sit omnis laborum. Voluptas illo voluptatem nihil quo incidunt animi. Fugiat aut consectetur iusto quaerat. Labore assumenda nisi assumenda autem commodi. Eaque est ad suscipit optio dolore enim. Natus iste non quo nobis iure magnam sed. Fugit omnis maiores quod non. Quos dolore dicta consequuntur ipsa expedita.', '394.00', '163.00', 'DIGI327', 'instock', 0, 171, 'digital_1.jpg', NULL, 6, NULL, '2022-03-29 04:18:00', '2022-03-29 04:18:00'),
(76, 'debitis deserunt et similique', 'debitis-deserunt-et-similique', 'Et quo laudantium soluta quae dolores libero. Fugiat sed impedit et ex assumenda ea. Rerum nam ad consequatur. Laboriosam occaecati consequatur laboriosam tempora ea eos id est.', 'Fugit est nostrum dolores excepturi distinctio. Vel dolores voluptates similique consequatur. Dolorem corporis harum autem dolores est dolores quis ut. Temporibus est quia rerum necessitatibus dolores est sed. Quidem impedit id consequuntur et. Error explicabo a nesciunt doloribus. Aut veritatis eos rerum itaque earum hic corrupti. Harum omnis placeat enim sequi. Et est minima dolores qui eum dolorem incidunt. Expedita ipsam eum et non. Delectus similique ea reprehenderit.', '393.00', '347.00', 'DIGI300', 'instock', 0, 122, 'digital_20.jpg', NULL, 6, NULL, '2022-03-29 04:18:00', '2022-03-29 04:18:00'),
(77, 'quia minus aut ut', 'quia-minus-aut-ut', 'Consequatur perspiciatis illum quia. Repellat id labore tenetur est voluptatibus qui. Nobis est et accusantium ea odio vero harum.', 'Nam quis officia pariatur consequatur placeat. Velit similique accusantium aperiam quidem reprehenderit fugit. Autem facere sit asperiores reprehenderit iste facilis sed. Ab beatae explicabo quo illum eos. Saepe dolorem amet a aspernatur. Placeat ex inventore voluptatibus quisquam facere. In alias nobis earum nihil qui ipsum cum. Nisi nobis dolorem ut et. Ad autem qui tenetur ex ea cumque. Cupiditate dolorem odio quibusdam. Nihil atque atque vel totam explicabo.', '212.00', '176.00', 'DIGI303', 'instock', 0, 170, 'digital_2.jpg', NULL, 6, NULL, '2022-03-29 04:18:00', '2022-03-29 04:18:00'),
(78, 'ut necessitatibus voluptas optio', 'ut-necessitatibus-voluptas-optio', 'Qui eos delectus libero. Corporis voluptate quibusdam quidem amet nesciunt sequi eos. Ipsa magni consequatur porro pariatur. Neque sint quas corrupti dolor non.', 'Voluptas et architecto modi dolorem. Dolor nemo cumque in earum. Architecto rerum neque ullam maxime magnam. Maiores sed hic impedit vero velit qui odio. Blanditiis omnis provident et non molestiae quasi. Aut ut deserunt rem consequatur quia. Dignissimos eos blanditiis ex sint veritatis. Fugiat dolorem sed ut. Recusandae harum harum recusandae eos laudantium. Aspernatur dolore harum eos aut. Rerum exercitationem voluptates aut impedit quia dolorum.', '363.00', '222.00', 'DIGI408', 'instock', 0, 182, 'digital_21.jpg', NULL, 4, NULL, '2022-03-29 04:18:00', '2022-03-29 04:18:00'),
(79, 'culpa placeat repudiandae molestiae', 'culpa-placeat-repudiandae-molestiae', 'Quis et iste voluptatibus praesentium. Nobis nihil recusandae rerum facilis. Nesciunt facere amet accusamus. Provident voluptates delectus dolores quod ducimus sed.', 'Ducimus quia cumque enim voluptatem. Soluta odio deleniti et est. Cumque ut nulla magnam quos velit pariatur voluptatem. Et distinctio itaque occaecati molestias id voluptatem illo. Doloremque est quae aliquid fuga tempore laborum. Provident omnis illum architecto nihil. Qui inventore sunt et blanditiis vel sit.', '159.00', '476.00', 'DIGI205', 'instock', 0, 171, 'digital_15.jpg', NULL, 3, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(80, 'quidem numquam ut omnis', 'quidem-numquam-ut-omnis', 'Aut deserunt dicta iure. Sunt nulla voluptatem voluptatem deleniti at atque hic. Dolorem dicta omnis ratione ut eum reprehenderit dolores. Voluptatem qui minima repellat aspernatur blanditiis autem.', 'Minus doloribus esse veniam non. Autem quisquam placeat unde rem corporis suscipit. Illum adipisci minima rerum quia. Ut non non culpa sit harum totam non qui. Laudantium non et dolorem est qui et consequatur. Atque impedit accusantium beatae blanditiis eius quia. Aut et sint eos culpa. Laborum illo sequi tempora est. Suscipit hic porro voluptatibus. Officiis ratione magni id illo. Nemo consequuntur voluptate atque sunt iusto. Ipsum consequuntur tempora deleniti neque.', '125.00', '317.00', 'DIGI485', 'instock', 0, 127, 'digital_14.jpg', NULL, 3, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(81, 'praesentium et ducimus unde', 'praesentium-et-ducimus-unde', 'Quam aperiam ea dolor reiciendis. Tenetur est perspiciatis sed. Est voluptas recusandae pariatur nihil est sed voluptatem.', 'Corporis omnis culpa reprehenderit iste. Eos quos officiis quam quod. Est assumenda accusantium ipsam ratione et. Sed tenetur dignissimos asperiores. Ipsam distinctio rerum sed quis nemo veniam. Fugit quam recusandae ea natus qui quasi est. Iste maiores pariatur quidem cumque est quisquam. Fuga fugit natus aspernatur eligendi. Qui quam a maxime doloremque. Sunt qui magni quo magni. Rerum odit sed at praesentium accusantium. Ex tempore in magnam cumque amet sunt.', '108.00', '365.00', 'DIGI367', 'instock', 0, 149, 'digital_16.jpg', NULL, 4, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(82, 'molestiae ut perspiciatis soluta', 'molestiae-ut-perspiciatis-soluta', 'Voluptatem nihil alias assumenda quia. Odio id ut doloribus id veniam aut enim. Magnam molestiae reiciendis cum ex. Nostrum quod tempora ipsa voluptates.', 'Vitae eum nostrum ad et animi. Recusandae iusto est repellat animi harum temporibus est enim. Doloremque praesentium fuga sed dolores sit dolorum. Quaerat animi exercitationem voluptas reprehenderit quia vitae. Sint vel in deleniti optio et libero blanditiis. Est labore dolores autem unde. Vel aut ea natus omnis. Porro fuga ut consequatur vel animi ipsa. Provident consequatur qui cumque hic qui. Consequatur reiciendis occaecati vel voluptates recusandae ab a. Velit unde consequatur inventore.', '105.00', '302.00', 'DIGI451', 'instock', 0, 189, 'digital_12.jpg', NULL, 1, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(83, 'voluptas vero tempora ex', 'voluptas-vero-tempora-ex', 'Fugit quidem aspernatur nisi quasi aut veniam quisquam. Quia qui debitis et vero molestiae aut laudantium. Quia facilis provident commodi porro.', 'Magnam autem libero vel sit exercitationem rem neque impedit. Et similique amet totam est dolorem ducimus rerum. Qui ipsa enim voluptate illum repellat. Debitis pariatur omnis omnis accusamus expedita est. Sit officiis deleniti qui et delectus. Provident aut natus qui aperiam a aut. Quibusdam voluptatem id distinctio ut non. Hic expedita fugiat tempora autem.', '106.00', '463.00', 'DIGI310', 'instock', 0, 110, 'digital_9.jpg', NULL, 1, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(84, 'autem ab fugiat consequatur', 'autem-ab-fugiat-consequatur', 'Provident voluptatem vero nihil et qui reprehenderit. Qui tempora quia esse magni. Eaque praesentium sapiente quod molestiae commodi et ex.', 'Voluptas assumenda minus placeat ut. Consequatur molestiae id possimus autem et. Sunt inventore voluptatem molestiae sed. Consequatur vel eveniet voluptas excepturi rerum. Voluptatem nemo sequi porro modi porro. Labore est ex itaque maxime aliquam explicabo. Et aut ut hic quam asperiores. Aut ut iste voluptatem dolores. Nulla dolorum culpa quae laudantium laudantium nesciunt.', '499.00', '469.00', 'DIGI104', 'instock', 0, 165, 'digital_22.jpg', NULL, 1, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(85, 'itaque sequi laboriosam praesentium', 'itaque-sequi-laboriosam-praesentium', 'Fugiat nemo non itaque. Est sed fugit at cumque hic fuga mollitia. Qui adipisci soluta esse id saepe sapiente veritatis. Ad maiores delectus quibusdam harum non magnam ut.', 'Aspernatur quam eligendi earum. At quia earum repellat rem. Voluptas aut corrupti nisi rerum. Officiis libero culpa dolores quaerat eos. Et tenetur perspiciatis impedit ea. Totam est error enim hic laboriosam. Molestiae doloribus quisquam impedit et odio. Voluptas sint quod illum provident sed assumenda saepe facere. Assumenda error natus necessitatibus aut vel enim et omnis. Ipsum incidunt consectetur enim. Iusto accusantium ratione recusandae nam qui explicabo eaque.', '284.00', '107.00', 'DIGI271', 'instock', 0, 113, 'digital_17.jpg', NULL, 5, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(86, 'labore aut dolores optio', 'labore-aut-dolores-optio', 'Optio rerum qui maiores corrupti officia dolor. Corrupti dolorem libero nihil blanditiis veniam possimus est. Et non quia nostrum et. Deleniti sed nulla voluptatum.', 'Quasi quia itaque facilis id qui. Et dolorum rerum necessitatibus. Quasi ea optio et recusandae atque aperiam fugit deserunt. In veniam pariatur non reiciendis error et. Eaque qui sit aut. Voluptatibus a enim voluptas delectus repudiandae. Qui enim dolor doloribus in harum. Consequatur enim recusandae suscipit quo. Rem voluptatibus molestiae harum nostrum voluptatem molestias fugit quisquam.', '355.00', '265.00', 'DIGI162', 'instock', 0, 167, 'digital_10.jpg', NULL, 1, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(87, 'dolore possimus est voluptatum', 'dolore-possimus-est-voluptatum', 'Porro officiis impedit sed ratione. Temporibus repellendus quia in quia. Nulla est debitis dolore perspiciatis aut velit accusantium.', 'Quas qui ut qui praesentium eaque. Sapiente autem magni modi eaque. Nihil in sapiente omnis soluta sed atque. Magni sint totam perferendis libero hic saepe maiores ratione. Fuga et optio ducimus quisquam hic. Eum nostrum itaque odio voluptatem. In delectus est eveniet officiis voluptatem dolore provident. Et in sapiente autem sint porro. Deleniti officiis sint numquam sed. Aliquid in consequatur excepturi ipsa dolores.', '145.00', '357.00', 'DIGI224', 'instock', 0, 185, 'digital_6.jpg', NULL, 5, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(88, 'velit illum quia consequatur', 'velit-illum-quia-consequatur', 'Ab in omnis repellendus repellendus et. Autem aperiam architecto in beatae laborum sit. In dolore in enim et labore velit non. Nulla sunt dolorum voluptates sequi. Quia ut voluptatem assumenda.', 'Animi veritatis culpa ut autem fugiat. Mollitia consequatur voluptates blanditiis quisquam. Qui nulla eligendi voluptas in hic molestiae. Expedita velit et quibusdam deserunt et qui eaque. Tempora est ipsam iste ullam numquam deleniti. Id iusto sit ea quod non est ipsam. Rerum laudantium repellat doloremque velit. Et consequatur qui rerum aperiam autem id ipsam.', '496.00', '351.00', 'DIGI435', 'instock', 0, 136, 'digital_4.jpg', NULL, 1, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(89, 'omnis neque dolore labore', 'omnis-neque-dolore-labore', 'Necessitatibus odit eveniet sunt qui voluptatem nobis praesentium. Dolores omnis ea velit recusandae. Unde in adipisci inventore consequatur aliquam.', 'Quo voluptatum sed ut eius quis reiciendis. Sint repellat quas nemo magni deleniti. Consectetur quo ut minima est. Eos qui quae eos et facilis hic et et. Consequatur fugiat hic sed. Consequatur et unde dolores possimus. Facere illo at amet et nostrum blanditiis dolores et. Qui corrupti praesentium aut excepturi nesciunt reprehenderit. Eum et ut non ut ullam ratione dolore. Aliquam reiciendis quod et dignissimos fugit. Asperiores quia sed excepturi.', '449.00', '420.00', 'DIGI376', 'instock', 0, 137, 'digital_3.jpg', NULL, 5, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(90, 'omnis magni vitae sed', 'omnis-magni-vitae-sed', 'Nisi recusandae qui placeat inventore similique praesentium dolores. Hic eum quae sed molestiae. Aspernatur aut autem quia magnam quas.', 'Illo repudiandae ullam ut sapiente quia harum. Reprehenderit qui ut esse eos facilis quas. Ipsa accusamus cupiditate ullam nam amet iusto. Perspiciatis et commodi exercitationem accusantium eos. Facere voluptate provident omnis sed occaecati. Consequatur aperiam dolor rerum et quod dolorem aperiam. Velit repellendus sed eum illo magnam et vero. Consequatur optio in qui et animi reprehenderit. Error eligendi sed nihil. Magni dolorem dolorum suscipit et consequatur.', '372.00', '108.00', 'DIGI420', 'instock', 0, 120, 'digital_7.jpg', NULL, 6, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(91, 'officia qui hic voluptatem', 'officia-qui-hic-voluptatem', 'Est sint rerum neque dolorem dolores tenetur quod. Ex est optio odio dolorum qui. Ad ut quia ea. Magni id id ut consequatur harum libero nam qui.', 'Dolore voluptas temporibus dolores occaecati reiciendis sit. Voluptate quibusdam asperiores voluptatem aut dolorem assumenda et eum. Sunt porro eius voluptatem qui hic velit. Dolore sint corrupti nihil iusto voluptas. Placeat sunt hic voluptas et sit. Molestiae autem animi accusantium nesciunt aliquid. Error voluptatem magni quod dicta voluptas eos. Eaque deserunt deleniti ut et voluptates facilis. Magnam et saepe ipsa soluta adipisci beatae corporis ad. Et ut dolorem illum.', '452.00', '378.00', 'DIGI177', 'instock', 0, 119, 'digital_18.jpg', NULL, 4, NULL, '2022-03-29 04:18:01', '2022-03-29 04:18:01'),
(92, 'ايفون 12', 'ayfon-12', '<p>ايفون 12</p>', '<p>ايفون 12</p>', '12000.00', '11000.00', '12shjsadhajhskdj', 'instock', 0, 1234, '1648887869-jpg', ',16488878690-jpg,16488878691-jpg,16488878692-jpg,16488878693-jpg', 5, NULL, '2022-04-02 06:24:29', '2022-04-02 06:24:29');

-- --------------------------------------------------------

--
-- بنية الجدول `product_attributes`
--

CREATE TABLE `product_attributes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zipcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `sales`
--

CREATE TABLE `sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sale_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `sales`
--

INSERT INTO `sales` (`id`, `sale_date`, `status`, `created_at`, `updated_at`) VALUES
(1, '2022-04-30 00:00:00', 1, '2022-03-31 22:00:00', '2022-03-31 22:00:00');

-- --------------------------------------------------------

--
-- بنية الجدول `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('HFOm4eYvdMhEfQjydzAgDRto3IPIJ1UCMjzRfCfF', 35, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36', 'YTo4OntzOjY6Il90b2tlbiI7czo0MDoieHBLYzc0ZG53d3dWaUcxYW15N05YSlpEVDlibUE4TjNCcUVVU3N1cCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9tc2hta19zaG9wLnRlc3QvY29udGFjdC11cyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM1O3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTAkR21aMUd2Z2Y5dWh5eVRJUFJPV2pIZVhtRHdQSWhEekVOS0kzUGZjVmdiLnVJdkVqWnZnb1MiO3M6NDoiY2FydCI7YToyOntzOjQ6ImNhcnQiO086Mjk6IklsbHVtaW5hdGVcU3VwcG9ydFxDb2xsZWN0aW9uIjoyOntzOjg6IgAqAGl0ZW1zIjthOjM6e3M6MzI6IjU1MDZjN2ZjMTYwNmEwODM0OWQ0ZmJjOTE4ZDQ4MzBiIjtPOjMyOiJHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbSI6OTp7czo1OiJyb3dJZCI7czozMjoiNTUwNmM3ZmMxNjA2YTA4MzQ5ZDRmYmM5MThkNDgzMGIiO3M6MjoiaWQiO2k6NTE7czozOiJxdHkiO2k6MTtzOjQ6Im5hbWUiO3M6NDoidGVzdCI7czo1OiJwcmljZSI7ZDo0OTY7czo3OiJvcHRpb25zIjtPOjM5OiJHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbU9wdGlvbnMiOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo0OToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGFzc29jaWF0ZWRNb2RlbCI7czoxODoiQXBwXE1vZGVsc1xQcm9kdWN0IjtzOjQxOiIAR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AdGF4UmF0ZSI7aToyMTtzOjQxOiIAR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AaXNTYXZlZCI7YjowO31zOjMyOiIzMGMyMTIwNzQ1ZDllNThmM2E4ZDRmNGFlMDNmYjE0NiI7TzozMjoiR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW0iOjk6e3M6NToicm93SWQiO3M6MzI6IjMwYzIxMjA3NDVkOWU1OGYzYThkNGY0YWUwM2ZiMTQ2IjtzOjI6ImlkIjtpOjU5O3M6MzoicXR5IjtpOjE7czo0OiJuYW1lIjtzOjIxOiJldCBmYWNpbGlzIGF0cXVlIGZ1Z2EiO3M6NToicHJpY2UiO2Q6MjczO3M6Nzoib3B0aW9ucyI7TzozOToiR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW1PcHRpb25zIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6NDk6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBhc3NvY2lhdGVkTW9kZWwiO3M6MTg6IkFwcFxNb2RlbHNcUHJvZHVjdCI7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAHRheFJhdGUiO2k6MjE7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGlzU2F2ZWQiO2I6MDt9czozMjoiMGIyZGQ1Y2RjZWNkNWJlMDYzNGY0Nzg2NzY2ZjAyOTciO086MzI6Ikdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtIjo5OntzOjU6InJvd0lkIjtzOjMyOiIwYjJkZDVjZGNlY2Q1YmUwNjM0ZjQ3ODY3NjZmMDI5NyI7czoyOiJpZCI7aTo3NztzOjM6InF0eSI7aToxO3M6NDoibmFtZSI7czoxNzoicXVpYSBtaW51cyBhdXQgdXQiO3M6NToicHJpY2UiO2Q6MTc2O3M6Nzoib3B0aW9ucyI7TzozOToiR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW1PcHRpb25zIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6NDk6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBhc3NvY2lhdGVkTW9kZWwiO3M6MTg6IkFwcFxNb2RlbHNcUHJvZHVjdCI7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAHRheFJhdGUiO2k6MjE7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGlzU2F2ZWQiO2I6MDt9fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo4OiJ3aXNobGlzdCI7TzoyOToiSWxsdW1pbmF0ZVxTdXBwb3J0XENvbGxlY3Rpb24iOjI6e3M6ODoiACoAaXRlbXMiO2E6Njp7czozMjoiNzcxMDcxNWI2MTAzM2FkY2YxN2I4ZTQxMjIxOGFhMWIiO086MzI6Ikdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtIjo5OntzOjU6InJvd0lkIjtzOjMyOiI3NzEwNzE1YjYxMDMzYWRjZjE3YjhlNDEyMjE4YWExYiI7czoyOiJpZCI7aTo1MjtzOjM6InF0eSI7aToxO3M6NDoibmFtZSI7czozMjoicXVpc3F1YW0gZW5pbSBkb2xvcnVtIGRvbG9yZW1xdWUiO3M6NToicHJpY2UiO2Q6MzkyO3M6Nzoib3B0aW9ucyI7TzozOToiR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW1PcHRpb25zIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6NDk6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBhc3NvY2lhdGVkTW9kZWwiO3M6MTg6IkFwcFxNb2RlbHNcUHJvZHVjdCI7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAHRheFJhdGUiO2k6MjE7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGlzU2F2ZWQiO2I6MDt9czozMjoiNTUwNmM3ZmMxNjA2YTA4MzQ5ZDRmYmM5MThkNDgzMGIiO086MzI6Ikdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtIjo5OntzOjU6InJvd0lkIjtzOjMyOiI1NTA2YzdmYzE2MDZhMDgzNDlkNGZiYzkxOGQ0ODMwYiI7czoyOiJpZCI7aTo1MTtzOjM6InF0eSI7aToxO3M6NDoibmFtZSI7czo0OiJ0ZXN0IjtzOjU6InByaWNlIjtkOjIzNTtzOjc6Im9wdGlvbnMiO086Mzk6Ikdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtT3B0aW9ucyI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjQ5OiIAR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AYXNzb2NpYXRlZE1vZGVsIjtzOjE4OiJBcHBcTW9kZWxzXFByb2R1Y3QiO3M6NDE6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQB0YXhSYXRlIjtpOjIxO3M6NDE6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBpc1NhdmVkIjtiOjA7fXM6MzI6IjM3ZDAyMTM4Nzk3NmY2NjUxMzBmZDBmZWM0MGMyNzlkIjtPOjMyOiJHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbSI6OTp7czo1OiJyb3dJZCI7czozMjoiMzdkMDIxMzg3OTc2ZjY2NTEzMGZkMGZlYzQwYzI3OWQiO3M6MjoiaWQiO2k6NDg7czozOiJxdHkiO2k6MjtzOjQ6Im5hbWUiO3M6MzoibmV3IjtzOjU6InByaWNlIjtkOjQxNTtzOjc6Im9wdGlvbnMiO086Mzk6Ikdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtT3B0aW9ucyI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjQ5OiIAR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AYXNzb2NpYXRlZE1vZGVsIjtzOjE4OiJBcHBcTW9kZWxzXFByb2R1Y3QiO3M6NDE6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQB0YXhSYXRlIjtpOjIxO3M6NDE6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBpc1NhdmVkIjtiOjA7fXM6MzI6IjU5ODNmYzJiYjIzNzk3YzRkNzE1OGVhNmNhNTViZjY1IjtPOjMyOiJHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbSI6OTp7czo1OiJyb3dJZCI7czozMjoiNTk4M2ZjMmJiMjM3OTdjNGQ3MTU4ZWE2Y2E1NWJmNjUiO3M6MjoiaWQiO2k6NTQ7czozOiJxdHkiO2k6MTtzOjQ6Im5hbWUiO3M6MjA6ImV0IGRvbG9yZXMgb21uaXMgbm9uIjtzOjU6InByaWNlIjtkOjIxMjtzOjc6Im9wdGlvbnMiO086Mzk6Ikdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtT3B0aW9ucyI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjQ5OiIAR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AYXNzb2NpYXRlZE1vZGVsIjtzOjE4OiJBcHBcTW9kZWxzXFByb2R1Y3QiO3M6NDE6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQB0YXhSYXRlIjtpOjIxO3M6NDE6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBpc1NhdmVkIjtiOjA7fXM6MzI6IjZkZTgzYWQyZjA2YTgwZWU1YjA2ZWFkNTFjYjc0ZmI1IjtPOjMyOiJHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbSI6OTp7czo1OiJyb3dJZCI7czozMjoiNmRlODNhZDJmMDZhODBlZTViMDZlYWQ1MWNiNzRmYjUiO3M6MjoiaWQiO2k6NTM7czozOiJxdHkiO2k6MTtzOjQ6Im5hbWUiO3M6MjI6ImV0IGFwZXJpYW0gc2FlcGUgcmVydW0iO3M6NToicHJpY2UiO2Q6Mjg0O3M6Nzoib3B0aW9ucyI7TzozOToiR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW1PcHRpb25zIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6NDk6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBhc3NvY2lhdGVkTW9kZWwiO3M6MTg6IkFwcFxNb2RlbHNcUHJvZHVjdCI7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAHRheFJhdGUiO2k6MjE7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGlzU2F2ZWQiO2I6MDt9czozMjoiMDJkZGJjMzQ3ZDc4NWY1YzQ3YmNiZTgxOTJlYTMwYzMiO086MzI6Ikdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtIjo5OntzOjU6InJvd0lkIjtzOjMyOiIwMmRkYmMzNDdkNzg1ZjVjNDdiY2JlODE5MmVhMzBjMyI7czoyOiJpZCI7aTo1NTtzOjM6InF0eSI7aToxO3M6NDoibmFtZSI7czoyOToib2ZmaWNpYSByZWljaWVuZGlzIG1heGltZSBxdWkiO3M6NToicHJpY2UiO2Q6MTE4O3M6Nzoib3B0aW9ucyI7TzozOToiR2xvdWRlbWFuc1xTaG9wcGluZ2NhcnRcQ2FydEl0ZW1PcHRpb25zIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6NDk6IgBHbG91ZGVtYW5zXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBhc3NvY2lhdGVkTW9kZWwiO3M6MTg6IkFwcFxNb2RlbHNcUHJvZHVjdCI7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAHRheFJhdGUiO2k6MjE7czo0MToiAEdsb3VkZW1hbnNcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGlzU2F2ZWQiO2I6MDt9fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9fXM6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJ5JDEwJEdtWjFHdmdmOXVoeXlUSVBST1dqSGVYbUR3UEloRHpFTktJM1BmY1ZnYi51SXZFalp2Z29TIjtzOjg6ImNoZWNrb3V0IjthOjQ6e3M6ODoiZGlzY291bnQiO2k6MDtzOjg6InN1YnRvdGFsIjtzOjY6Ijk0NS4wMCI7czozOiJ0YXgiO3M6NjoiMTk4LjQ1IjtzOjU6InRvdGFsIjtzOjg6IjEsMTQzLjQ1Ijt9fQ==', 1648955267);

-- --------------------------------------------------------

--
-- بنية الجدول `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `store_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_cost` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `map` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_1_icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_1_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_1_subtitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_2_icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_2_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_2_subtitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_3_icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_3_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_3_subtitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_4_icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_4_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_4_subtitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twiter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinterest` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `copyright` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `copyright_links` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `download_app_link_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `download_app_link_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twin_banner_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twin_banner_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latest_products_banner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `products_by_section_banner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shop_banner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `about_shop_page_body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `terms_page_body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `about_privacy_body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `about_return_body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `about_faq_body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `settings`
--

INSERT INTO `settings` (`id`, `store_name`, `currency`, `shipping_cost`, `logo_1`, `logo_mobile`, `email`, `phone`, `phone2`, `address`, `map`, `section_1_icon`, `section_1_title`, `section_1_subtitle`, `section_2_icon`, `section_2_title`, `section_2_subtitle`, `section_3_icon`, `section_3_title`, `section_3_subtitle`, `section_4_icon`, `section_4_title`, `section_4_subtitle`, `twiter`, `facebook`, `pinterest`, `instagram`, `youtube`, `copyright`, `copyright_links`, `download_app_link_1`, `download_app_link_2`, `payment_image`, `twin_banner_1`, `twin_banner_2`, `latest_products_banner`, `products_by_section_banner`, `shop_banner`, `about_shop_page_body`, `terms_page_body`, `about_privacy_body`, `about_return_body`, `about_faq_body`, `created_at`, `updated_at`) VALUES
(1, 'x', 'x', 'x', 'x', 'x', 'test@gmail.com', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.\n\nهذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.', NULL, '2022-04-03 00:09:04');

-- --------------------------------------------------------

--
-- بنية الجدول `shippings`
--

CREATE TABLE `shippings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `line1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- بنية الجدول `shoppingcart`
--

CREATE TABLE `shoppingcart` (
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instance` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `shoppingcart`
--

INSERT INTO `shoppingcart` (`identifier`, `instance`, `content`, `created_at`, `updated_at`) VALUES
('test@gmail.com', 'cart', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:1:{s:32:\"f096033013513ac018c9a756f3259ce4\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"f096033013513ac018c9a756f3259ce4\";s:2:\"id\";i:391;s:3:\"qty\";i:1;s:4:\"name\";s:20:\"magni velit quia quo\";s:5:\"price\";d:368;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-22 10:08:55', NULL),
('test@gmail.com', 'wishlist', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-22 10:43:26', NULL),
('any@gmail.com', 'wishlist', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-23 11:19:14', NULL),
('admin@admin.com', 'wishlist', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 03:50:18', NULL),
('admin@admin.com', 'cart', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:1:{s:32:\"a775bac9cff7dec2b984e023b95206aa\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"a775bac9cff7dec2b984e023b95206aa\";s:2:\"id\";i:3;s:3:\"qty\";i:3;s:4:\"name\";s:22:\"nulla expedita vel qui\";s:5:\"price\";d:171;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-29 03:50:30', NULL),
('admisassasn@gmail.com', 'cart', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:2:{s:32:\"f528876ea1423c93e3201a14f2eb48b7\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"f528876ea1423c93e3201a14f2eb48b7\";s:2:\"id\";i:49;s:3:\"qty\";i:1;s:4:\"name\";s:21:\"illum omnis atque qui\";s:5:\"price\";d:408;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"4a734e13ccac27a70100bb2e2a3587f0\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"4a734e13ccac27a70100bb2e2a3587f0\";s:2:\"id\";i:50;s:3:\"qty\";i:1;s:4:\"name\";s:24:\"modi non sint laboriosam\";s:5:\"price\";d:496;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-30 08:50:57', NULL),
('admisassasn@gmail.com', 'wishlist', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-31 10:40:14', NULL),
('test@admin.com', 'cart', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:2:{s:32:\"4a734e13ccac27a70100bb2e2a3587f0\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"4a734e13ccac27a70100bb2e2a3587f0\";s:2:\"id\";i:50;s:3:\"qty\";i:1;s:4:\"name\";s:24:\"modi non sint laboriosam\";s:5:\"price\";d:496;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"f528876ea1423c93e3201a14f2eb48b7\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"f528876ea1423c93e3201a14f2eb48b7\";s:2:\"id\";i:49;s:3:\"qty\";i:1;s:4:\"name\";s:21:\"illum omnis atque qui\";s:5:\"price\";d:408;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-31 12:16:30', NULL),
('test@admin.com', 'wishlist', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-31 12:16:42', NULL),
('admin@gmail.com', 'cart', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:1:{s:32:\"37d021387976f665130fd0fec40c279d\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"37d021387976f665130fd0fec40c279d\";s:2:\"id\";i:48;s:3:\"qty\";i:7;s:4:\"name\";s:3:\"new\";s:5:\"price\";d:415;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-31 21:42:09', NULL),
('admin@gmail.com', 'wishlist', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:5:{s:32:\"7710715b61033adcf17b8e412218aa1b\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"7710715b61033adcf17b8e412218aa1b\";s:2:\"id\";i:52;s:3:\"qty\";i:1;s:4:\"name\";s:32:\"quisquam enim dolorum doloremque\";s:5:\"price\";d:392;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"6de83ad2f06a80ee5b06ead51cb74fb5\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"6de83ad2f06a80ee5b06ead51cb74fb5\";s:2:\"id\";i:53;s:3:\"qty\";i:1;s:4:\"name\";s:22:\"et aperiam saepe rerum\";s:5:\"price\";d:284;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"88aad65a1416c8271cddc2ee48e4a30b\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"88aad65a1416c8271cddc2ee48e4a30b\";s:2:\"id\";i:56;s:3:\"qty\";i:1;s:4:\"name\";s:21:\"labore id ut sapiente\";s:5:\"price\";d:488;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"02ddbc347d785f5c47bcbe8192ea30c3\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"02ddbc347d785f5c47bcbe8192ea30c3\";s:2:\"id\";i:55;s:3:\"qty\";i:1;s:4:\"name\";s:29:\"officia reiciendis maxime qui\";s:5:\"price\";d:118;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"5983fc2bb23797c4d7158ea6ca55bf65\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"5983fc2bb23797c4d7158ea6ca55bf65\";s:2:\"id\";i:54;s:3:\"qty\";i:1;s:4:\"name\";s:20:\"et dolores omnis non\";s:5:\"price\";d:212;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-03-31 22:48:47', NULL),
('test@test.com', 'cart', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-04-01 00:05:01', NULL),
('test@test.com', 'wishlist', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-04-01 01:24:30', NULL),
('masry_shop@admin.com', 'cart', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:3:{s:32:\"5506c7fc1606a08349d4fbc918d4830b\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"5506c7fc1606a08349d4fbc918d4830b\";s:2:\"id\";i:51;s:3:\"qty\";i:1;s:4:\"name\";s:4:\"test\";s:5:\"price\";d:496;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"30c2120745d9e58f3a8d4f4ae03fb146\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"30c2120745d9e58f3a8d4f4ae03fb146\";s:2:\"id\";i:59;s:3:\"qty\";i:1;s:4:\"name\";s:21:\"et facilis atque fuga\";s:5:\"price\";d:273;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"0b2dd5cdcecd5be0634f4786766f0297\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"0b2dd5cdcecd5be0634f4786766f0297\";s:2:\"id\";i:77;s:3:\"qty\";i:1;s:4:\"name\";s:17:\"quia minus aut ut\";s:5:\"price\";d:176;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-04-02 22:47:00', NULL),
('masry_shop@admin.com', 'wishlist', 'O:29:\"Illuminate\\Support\\Collection\":2:{s:8:\"\0*\0items\";a:6:{s:32:\"7710715b61033adcf17b8e412218aa1b\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"7710715b61033adcf17b8e412218aa1b\";s:2:\"id\";i:52;s:3:\"qty\";i:1;s:4:\"name\";s:32:\"quisquam enim dolorum doloremque\";s:5:\"price\";d:392;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"5506c7fc1606a08349d4fbc918d4830b\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"5506c7fc1606a08349d4fbc918d4830b\";s:2:\"id\";i:51;s:3:\"qty\";i:1;s:4:\"name\";s:4:\"test\";s:5:\"price\";d:235;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"37d021387976f665130fd0fec40c279d\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"37d021387976f665130fd0fec40c279d\";s:2:\"id\";i:48;s:3:\"qty\";i:2;s:4:\"name\";s:3:\"new\";s:5:\"price\";d:415;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"5983fc2bb23797c4d7158ea6ca55bf65\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"5983fc2bb23797c4d7158ea6ca55bf65\";s:2:\"id\";i:54;s:3:\"qty\";i:1;s:4:\"name\";s:20:\"et dolores omnis non\";s:5:\"price\";d:212;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"6de83ad2f06a80ee5b06ead51cb74fb5\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"6de83ad2f06a80ee5b06ead51cb74fb5\";s:2:\"id\";i:53;s:3:\"qty\";i:1;s:4:\"name\";s:22:\"et aperiam saepe rerum\";s:5:\"price\";d:284;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}s:32:\"02ddbc347d785f5c47bcbe8192ea30c3\";O:32:\"Gloudemans\\Shoppingcart\\CartItem\":9:{s:5:\"rowId\";s:32:\"02ddbc347d785f5c47bcbe8192ea30c3\";s:2:\"id\";i:55;s:3:\"qty\";i:1;s:4:\"name\";s:29:\"officia reiciendis maxime qui\";s:5:\"price\";d:118;s:7:\"options\";O:39:\"Gloudemans\\Shoppingcart\\CartItemOptions\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}s:49:\"\0Gloudemans\\Shoppingcart\\CartItem\0associatedModel\";s:18:\"App\\Models\\Product\";s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0taxRate\";i:21;s:41:\"\0Gloudemans\\Shoppingcart\\CartItem\0isSaved\";b:0;}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}', '2022-04-03 00:08:25', NULL);

-- --------------------------------------------------------

--
-- بنية الجدول `subcategories`
--

CREATE TABLE `subcategories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `subcategories`
--

INSERT INTO `subcategories` (`id`, `name`, `slug`, `category_id`, `created_at`, `updated_at`) VALUES
(2, 'new section', 'new-section', 1, '2022-04-02 05:17:36', '2022-04-02 05:17:36'),
(3, 'new section', 'new-section', 1, '2022-04-02 05:17:40', '2022-04-02 05:17:40'),
(4, 'ssss', 'ssss', 1, '2022-04-02 05:17:59', '2022-04-02 05:17:59'),
(5, 'اقسام فرعية', 'aksam-fraay', 1, '2022-04-02 05:23:56', '2022-04-02 05:23:56'),
(6, 'ssssssssssssss', 'ssssssssssssss', 19, '2022-04-02 05:40:36', '2022-04-02 05:40:36');

-- --------------------------------------------------------

--
-- بنية الجدول `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `mode` enum('cod','card','paypal') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','approved','declined','refunded') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `order_id`, `mode`, `status`, `created_at`, `updated_at`) VALUES
(1, 35, 1, 'cod', 'pending', '2022-04-02 02:12:34', '2022-04-02 02:12:34'),
(2, 35, 2, 'cod', 'pending', '2022-04-02 06:26:19', '2022-04-02 06:26:19');

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USR' COMMENT 'ADM FOR ADMIN AND USR FOR USER OR CUSTOMER',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `current_team_id`, `profile_photo_path`, `utype`, `created_at`, `updated_at`) VALUES
(35, 'محمود سامي حسين متولي', 'masry_shop@admin.com', NULL, '$2y$10$GmZ1Gvgf9uhyyTIPROWjHeXmDwPIhDzENKI3PfcVgb.uIvEjZvgoS', NULL, NULL, NULL, NULL, NULL, 'ADM', '2022-04-01 01:27:05', '2022-04-01 01:27:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attribute_values`
--
ALTER TABLE `attribute_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_values_product_attribute_id_foreign` (`product_attribute_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `homesliders`
--
ALTER TABLE `homesliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_categories`
--
ALTER TABLE `home_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_attributes`
--
ALTER TABLE `product_attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profiles_user_id_foreign` (`user_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shippings`
--
ALTER TABLE `shippings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shippings_order_id_foreign` (`order_id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transactions_user_id_foreign` (`user_id`),
  ADD KEY `transactions_order_id_foreign` (`order_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attribute_values`
--
ALTER TABLE `attribute_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `homesliders`
--
ALTER TABLE `homesliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `home_categories`
--
ALTER TABLE `home_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `product_attributes`
--
ALTER TABLE `product_attributes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shippings`
--
ALTER TABLE `shippings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- قيود الجداول المحفوظة
--

--
-- القيود للجدول `attribute_values`
--
ALTER TABLE `attribute_values`
  ADD CONSTRAINT `attribute_values_product_attribute_id_foreign` FOREIGN KEY (`product_attribute_id`) REFERENCES `product_attributes` (`id`) ON DELETE CASCADE;

--
-- القيود للجدول `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- القيود للجدول `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL;

--
-- القيود للجدول `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- القيود للجدول `shippings`
--
ALTER TABLE `shippings`
  ADD CONSTRAINT `shippings_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- القيود للجدول `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
